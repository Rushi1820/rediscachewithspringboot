package com.example.redisproject.redisproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
